<?php
namespace Opencart\Catalog\Controller\Extension\Recently_viewed\Language;
// Heading
$_['heading_title'] = 'Recently Viewed';
